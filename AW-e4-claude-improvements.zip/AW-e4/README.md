# ARAOUAA Premium

Site vitrine statique (HTML/CSS/JS) pour ARAOUAA, produits du terroir marocain.

- Page d'accueil : `index.html` — catalogue : `produits.html`
- Déploiement : GitHub Pages via `.github/workflows/pages.yml` (branche `Aw.5`)
- Aperçu local : `python3 -m http.server` puis http://localhost:8000

## Branche `claude-improvements`
Logo allégé (3,2 Mo → WebP 900 px, original conservé), favicon + balises de partage, coordonnées réelles sur l'accueil, formulaire de contact honnête (ouvre l'e-mail au lieu de simuler l'envoi), `robots.txt`, README.

## Direction « Atelier » (v2)
`v2/index.html` : site d'une seule page (accueil, espace professionnels avec liste de prix, impression PDF et demande de devis, fiche de lot avec QR code), FR / EN / AR avec mise en page RTL, mode sombre automatique. Les certifications et l'histoire du producteur sont à compléter ; le lot AW-2026-0412 est un exemple fictif.
